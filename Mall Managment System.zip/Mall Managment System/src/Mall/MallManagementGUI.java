package Mall;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MallManagementGUI {
    private JFrame frame;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private HashMap<String, String> users;
    private Admin admin;
    private Staff staff;
    private Tenants tenant;
    private Feedback feedback;

    public MallManagementGUI() {
        users = new HashMap<>();
        users.put("admin123", "adminpass");
        users.put("staff456", "staffpass");
        users.put("tenant789", "tenantpass");

        admin = new Admin();
        staff = new Staff("staff456");
        tenant = new Tenants("tenant789");
        feedback = new Feedback();

        frame = new JFrame("Mall Management System");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), "Login");
        mainPanel.add(createAdminPanel(), "Admin");
        mainPanel.add(createStaffPanel(), "Staff");
        mainPanel.add(createTenantPanel(), "Tenant");
        mainPanel.add(createCustomerFeedbackPanel(), "CustomerFeedback");
        mainPanel.add(createCustomerFeedbackPanel(), "CustomerFeedback");

        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 1));
        JTextField idField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton customerFeedbackButton = new JButton("Give Feedback");

        panel.add(new JLabel("Enter ID:"));
        panel.add(idField);
        panel.add(new JLabel("Enter Password:"));
        panel.add(passField);
        panel.add(loginButton);
        panel.add(customerFeedbackButton);

        loginButton.addActionListener(e -> {
            String id = idField.getText();
            String password = new String(passField.getPassword());

            if (users.containsKey(id) && users.get(id).equals(password)) {
                if (id.startsWith("admin")) cardLayout.show(mainPanel, "Admin");
                else if (id.startsWith("staff")) cardLayout.show(mainPanel, "Staff");
                else if (id.startsWith("tenant")) cardLayout.show(mainPanel, "Tenant");
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid Credentials!");
            }
        });

        customerFeedbackButton.addActionListener(e -> cardLayout.show(mainPanel, "CustomerFeedback"));
        return panel;
    }

    private JPanel createAdminPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 1));
        JButton processTenantIssue = new JButton("Process Tenant Issue");
        JButton processMechanicalIssue = new JButton("Process Mechanical Issue");
        JButton viewPayments = new JButton("View Tenant Payments");
        JButton processFeedback = new JButton("Process Feedback");
        JButton completeEvent = new JButton("Complete Event");
        JButton scheduleEvent = new JButton("Schedule Event");
        JButton logoutButton = new JButton("Logout");

        panel.add(processTenantIssue);
        panel.add(processMechanicalIssue);
        panel.add(viewPayments);
        panel.add(processFeedback);
        panel.add(completeEvent);
        panel.add(scheduleEvent);
        panel.add(logoutButton);

        processTenantIssue.addActionListener(e -> admin.processTenantComplaint());
        processMechanicalIssue.addActionListener(e -> admin.processMechanicalIssue());
        viewPayments.addActionListener(e -> admin.showPayments());
        processFeedback.addActionListener(e -> feedback.processFeedback());
        completeEvent.addActionListener(e -> feedback.completeEvent());
        scheduleEvent.addActionListener(e -> feedback.scheduleEvent("New Event"));
        logoutButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        return panel;
    }

    private JPanel createStaffPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 1));
        JTextField issueField = new JTextField();
        JButton reportMechanicalIssueButton = new JButton("Report Mechanical Issue");
        JButton reportTenantIssueButton = new JButton("Report Tenant Issue");
        JButton reportCleaningIssueButton = new JButton("Report Cleaning Issue");
        JButton reportSecurityIssueButton = new JButton("Report Security Issue");
        JButton logoutButton = new JButton("Logout");

        panel.add(new JLabel("Enter Issue:"));
        panel.add(issueField);
        panel.add(reportMechanicalIssueButton);
        panel.add(reportTenantIssueButton);
        panel.add(reportCleaningIssueButton);
        panel.add(reportSecurityIssueButton);
        panel.add(logoutButton);

        reportMechanicalIssueButton.addActionListener(e -> staff.reportMechanicalIssue(issueField.getText(), admin));
        reportTenantIssueButton.addActionListener(e -> staff.reportTenantIssue(issueField.getText(), admin));
        reportCleaningIssueButton.addActionListener(e -> staff.reportCleaningIssue(issueField.getText()));
        reportSecurityIssueButton.addActionListener(e -> staff.reportSecurityIssue(issueField.getText()));
        logoutButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        return panel;
    }

    private JPanel createTenantPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 1));
        JTextField issueField = new JTextField();
        JButton fileComplaintButton = new JButton("File Complaint");
        JButton makePaymentButton = new JButton("Make Payment");
        JButton logoutButton = new JButton("Logout");

        panel.add(new JLabel("Enter Issue:"));
        panel.add(issueField);
        panel.add(fileComplaintButton);
        panel.add(makePaymentButton);
        panel.add(logoutButton);

        fileComplaintButton.addActionListener(e -> tenant.fileComplaint(issueField.getText(), admin));
        makePaymentButton.addActionListener(e -> tenant.makePayment(100, admin));
        logoutButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        return panel;
    }

    private JPanel createCustomerFeedbackPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 1));
        JTextField phoneField = new JTextField();
        JTextField feedbackField = new JTextField();
        JButton submitButton = new JButton("Submit Feedback");
        JButton backButton = new JButton("Back");

        panel.add(new JLabel("Enter Phone Number:"));
        panel.add(phoneField);
        panel.add(new JLabel("Enter Feedback:"));
        panel.add(feedbackField);
        panel.add(submitButton);
        panel.add(backButton);

        submitButton.addActionListener(e -> {
            feedback.addFeedback(feedbackField.getText());
            JOptionPane.showMessageDialog(frame, "Feedback Submitted! Thank You.");
        });

        backButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));
        return panel;
    }

    public static void main(String[] args) {
        new MallManagementGUI();
    }
}
