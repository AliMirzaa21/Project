package Mall;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;


class Feedback {
    Stack<String> customerFeedback = new Stack<>();
    Queue<String> upcomingEvents = new LinkedList<>();

    // Add Customer Feedback
    public void addFeedback(String feedback) {
        customerFeedback.push(feedback);
        System.out.println("Feedback received: " + feedback);
    }

    // Process Feedback
    public void processFeedback() {
        if (!customerFeedback.isEmpty()) {
            System.out.println("Processing Feedback: " + customerFeedback.pop());
        } else {
            System.out.println("No feedback to process.");
        }
    }

    // Schedule Event
    public void scheduleEvent(String event) {
        upcomingEvents.add(event);
        System.out.println("Event scheduled: " + event);
    }

    // Complete Event
    public void completeEvent() {
        if (!upcomingEvents.isEmpty()) {
            System.out.println("Event completed: " + upcomingEvents.poll());
        } else {
            System.out.println("No upcoming events.");
        }
    }
}
