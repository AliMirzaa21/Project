package Mall;
import java.util.LinkedList;
import java.util.Queue;


class Staff {
    String employeeId;
    Queue<String> cleaningIssues = new LinkedList<>();
    Queue<String> securityIssues = new LinkedList<>();

    Staff(String employeeId) {
        this.employeeId = employeeId;
    }

    // Add Mechanical Issue
    public void reportMechanicalIssue(String issue, Admin admin) {
        admin.mechanicalIssues.add(issue);
        System.out.println("Mechanical Issue reported: " + issue);
    }

    // Add Tenant Issue
    public void reportTenantIssue(String complaint, Admin admin) {
        admin.tenantComplaints.add(complaint);
        System.out.println("Tenant complaint reported: " + complaint);
    }

    // Add Cleaning Issue
    public void reportCleaningIssue(String issue) {
        cleaningIssues.add(issue);
        System.out.println("Cleaning Issue added: " + issue);
    }

    // Add Security Issue
    public void reportSecurityIssue(String issue) {
        securityIssues.add(issue);
        System.out.println("Security Issue added: " + issue);
    }

    // Resolve Cleaning Issue
    public void resolveCleaningIssue() {
        if (!cleaningIssues.isEmpty()) {
            System.out.println("Cleaning issue resolved: " + cleaningIssues.poll());
        } else {
            System.out.println("No cleaning issues.");
        }
    }

    // Resolve Security Issue
    public void resolveSecurityIssue() {
        if (!securityIssues.isEmpty()) {
            System.out.println("Security issue resolved: " + securityIssues.poll());
        } else {
            System.out.println("No security issues.");
        }
    }
}

