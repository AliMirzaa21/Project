package Mall;

class Tenants {
    String tenantId;

    Tenants(String tenantId) {
        this.tenantId = tenantId;
    }

    // Make Payment
    public void makePayment(double amount, Admin admin) {
        admin.addTenantPayment(tenantId, amount);
    }

    // File Complaint
    public void fileComplaint(String complaint, Admin admin) {
        admin.tenantComplaints.add(complaint);
        System.out.println("Complaint filed: " + complaint);
    }
}
