
package Mall;
import java.util.LinkedList;
import java.util.Queue;
import java.util.HashMap;

class Admin {
    Queue<String> tenantComplaints = new LinkedList<>();
    Queue<String> mechanicalIssues = new LinkedList<>();
    HashMap<String, Double> tenantPayments = new HashMap<>(); // Tenant ID -> Payment Amount

    // Process Tenant Complaints
    public void processTenantComplaint() {
        if (!tenantComplaints.isEmpty()) {
            System.out.println("Processing Tenant Complaint: " + tenantComplaints.poll());
        } else {
            System.out.println("No complaints to process.");
        }
    }

    // Process Mechanical Issues
    public void processMechanicalIssue() {
        if (!mechanicalIssues.isEmpty()) {
            System.out.println("Fixing Mechanical Issue: " + mechanicalIssues.poll());
        } else {
            System.out.println("No mechanical issues pending.");
        }
    }

    // Track Tenant Payments
    public void addTenantPayment(String tenantId, double amount) {
        tenantPayments.put(tenantId, amount);
        System.out.println("Payment received from Tenant " + tenantId + ": $" + amount);
    }

    public void showPayments() {
        System.out.println("Tenant Payments: " + tenantPayments);
    }
}

